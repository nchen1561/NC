IF OBJECT_ID('tempdb..#RecentIROPEvents') IS NOT NULL DROP TABLE #RecentIROPEvents;

CREATE TABLE #RecentIROPEvents (
    Flight_ID VARCHAR(20),        
    Flight_Number VARCHAR(10),
    Flight_Date DATE,
    Origin_Airport VARCHAR(3),
    Destination_Airport VARCHAR(3),
    Scheduled_Departure DATETIME,
    Actual_Departure DATETIME,
    Scheduled_Arrival DATETIME,
    Actual_Arrival DATETIME,
    IROP_Type VARCHAR(100),
    Delay_Bucket VARCHAR(20),
    Controllability VARCHAR(20),
    Flight_Key VARCHAR(50)        
);

INSERT INTO #RecentIROPEvents (
    Flight_ID,
    Flight_Number,
    Flight_Date,
    Origin_Airport,
    Destination_Airport,
    Scheduled_Departure,
    Actual_Departure,
    Scheduled_Arrival,
    Actual_Arrival,
    IROP_Type,
    Delay_Bucket,
    Controllability,
    Flight_Key
)
SELECT

    CAST(f.FlightRecId AS VARCHAR(20)) AS Flight_ID,
    CAST(f.Flt AS VARCHAR(10)) AS Flight_Number,
    f.LocalDate AS Flight_Date,
    f.ActOrig AS Origin_Airport,
    f.ActDest AS Destination_Airport,
    f.SchLocal_OUT AS Scheduled_Departure,
    f.ActLocal_OUT AS Actual_Departure,
    f.SchLocal_IN AS Scheduled_Arrival,
    f.ActLocal_IN AS Actual_Arrival,

    CASE 
        WHEN f.CancelFlag = 1 THEN 
            CASE 
                WHEN UPPER(COALESCE(dc.DOT_Description, f.CancelRsn, '')) LIKE '%WEATHER%' OR UPPER(COALESCE(dc.DOT_Description, f.CancelRsn, '')) LIKE '%WX%' THEN 'CANCELLATION - Weather'
                WHEN UPPER(COALESCE(dc.DOT_Description, f.CancelRsn, '')) LIKE '%ATC%' OR UPPER(COALESCE(dc.DOT_Description, f.CancelRsn, '')) LIKE '%NATIONAL%' THEN 'CANCELLATION - National Aviation System'
                WHEN UPPER(COALESCE(dc.DOT_Description, f.CancelRsn, '')) LIKE '%SECURITY%' THEN 'CANCELLATION - Security'
                WHEN COALESCE(dc.DOT_Description, f.CancelRsn, '') != '' THEN CONCAT('CANCELLATION - ', COALESCE(dc.DOT_Description, f.CancelRsn))
                ELSE 'CANCELLATION - Carrier Caused'
            END
        WHEN f.DiversionFlag = 1 THEN 
            CASE 
                WHEN UPPER(COALESCE(dd.DOT_Description, fd.DelayRsn, '')) LIKE '%WEATHER%' OR UPPER(COALESCE(dd.DOT_Description, fd.DelayRsn, '')) LIKE '%WX%' THEN 'DIVERSION - Weather'
                WHEN UPPER(COALESCE(dd.DOT_Description, fd.DelayRsn, '')) LIKE '%ATC%' OR UPPER(COALESCE(dd.DOT_Description, fd.DelayRsn, '')) LIKE '%NATIONAL%' THEN 'DIVERSION - National Aviation System'
                WHEN UPPER(COALESCE(dd.DOT_Description, fd.DelayRsn, '')) LIKE '%LATE%' OR UPPER(COALESCE(dd.DOT_Description, fd.DelayRsn, '')) LIKE '%AIRCRAFT%' THEN 'DIVERSION - Late Arriving Aircraft'
                WHEN COALESCE(dd.DOT_Description, fd.DelayRsn, '') != '' THEN CONCAT('DIVERSION - ', COALESCE(dd.DOT_Description, fd.DelayRsn))
                ELSE 'DIVERSION - Carrier Caused'
            END
        WHEN DATEDIFF(MINUTE, f.SchLocal_OUT, f.ActLocal_OUT) >= 15 THEN 
            CASE 
                WHEN UPPER(COALESCE(dd.DOT_Description, fd.DelayRsn, '')) LIKE '%WEATHER%' OR UPPER(COALESCE(dd.DOT_Description, fd.DelayRsn, '')) LIKE '%WX%' THEN 'DELAY - Weather'
                WHEN UPPER(COALESCE(dd.DOT_Description, fd.DelayRsn, '')) LIKE '%ATC%' OR UPPER(COALESCE(dd.DOT_Description, fd.DelayRsn, '')) LIKE '%NATIONAL%' THEN 'DELAY - National Aviation System'
                WHEN UPPER(COALESCE(dd.DOT_Description, fd.DelayRsn, '')) LIKE '%SECURITY%' THEN 'DELAY - Security'
                WHEN UPPER(COALESCE(dd.DOT_Description, fd.DelayRsn, '')) LIKE '%LATE%' OR UPPER(COALESCE(dd.DOT_Description, fd.DelayRsn, '')) LIKE '%AIRCRAFT%' THEN 'DELAY - Late Arriving Aircraft'
                WHEN COALESCE(dd.DOT_Description, fd.DelayRsn, '') != '' THEN CONCAT('DELAY - ', COALESCE(dd.DOT_Description, fd.DelayRsn))
                ELSE 'DELAY - Carrier Caused'
            END
        ELSE 'ON_TIME'
    END AS IROP_Type,

    CASE 
        WHEN f.CancelFlag = 1 OR f.DiversionFlag = 1 THEN 'N/A'
        WHEN DATEDIFF(MINUTE, f.SchLocal_OUT, f.ActLocal_OUT) >= 480 THEN '8+ HOURS'
        WHEN DATEDIFF(MINUTE, f.SchLocal_OUT, f.ActLocal_OUT) >= 180 THEN '3�8 HOURS'
        WHEN DATEDIFF(MINUTE, f.SchLocal_OUT, f.ActLocal_OUT) >= 60 THEN '1�3 HOURS'
        WHEN DATEDIFF(MINUTE, f.SchLocal_OUT, f.ActLocal_OUT) >= 15 THEN '15�60 MINS'
        ELSE 'N/A'
    END AS Delay_Bucket,

    CASE 

        WHEN f.CancelFlag = 1 AND (
            UPPER(COALESCE(dc.DOT_Description, f.CancelRsn, '')) LIKE '%CARRIER%' OR
            UPPER(COALESCE(dc.DOT_Description, f.CancelRsn, '')) LIKE '%MX%' OR
            UPPER(COALESCE(dc.DOT_Description, f.CancelRsn, '')) LIKE '%MAINTENANCE%' OR
            UPPER(COALESCE(dc.DOT_Description, f.CancelRsn, '')) LIKE '%CREW%' OR
            UPPER(COALESCE(dc.DOT_Description, f.CancelRsn, '')) LIKE '%AIRCRAFT%' OR
            (COALESCE(dc.DOT_Description, f.CancelRsn, '') = '' AND f.CancelFlag = 1)
        ) THEN 'CONTROLLABLE'

        WHEN f.DiversionFlag = 1 AND (
            UPPER(COALESCE(dd.DOT_Description, fd.DelayRsn, '')) LIKE '%CARRIER%' OR
            UPPER(COALESCE(dd.DOT_Description, fd.DelayRsn, '')) LIKE '%LATE%' OR
            UPPER(COALESCE(dd.DOT_Description, fd.DelayRsn, '')) LIKE '%AIRCRAFT%' OR
            UPPER(COALESCE(dd.DOT_Description, fd.DelayRsn, '')) LIKE '%MX%' OR
            UPPER(COALESCE(dd.DOT_Description, fd.DelayRsn, '')) LIKE '%MAINTENANCE%' OR
            UPPER(COALESCE(dd.DOT_Description, fd.DelayRsn, '')) LIKE '%CREW%'
        ) THEN 'CONTROLLABLE'

        WHEN DATEDIFF(MINUTE, f.SchLocal_OUT, f.ActLocal_OUT) >= 15 AND (
            UPPER(COALESCE(dd.DOT_Description, fd.DelayRsn, '')) LIKE '%CARRIER%' OR
            UPPER(COALESCE(dd.DOT_Description, fd.DelayRsn, '')) LIKE '%LATE%' OR
            UPPER(COALESCE(dd.DOT_Description, fd.DelayRsn, '')) LIKE '%AIRCRAFT%' OR
            UPPER(COALESCE(dd.DOT_Description, fd.DelayRsn, '')) LIKE '%MX%' OR
            UPPER(COALESCE(dd.DOT_Description, fd.DelayRsn, '')) LIKE '%MAINTENANCE%' OR
            UPPER(COALESCE(dd.DOT_Description, fd.DelayRsn, '')) LIKE '%CREW%' OR
            (COALESCE(dd.DOT_Description, fd.DelayRsn, '') = '' AND DATEDIFF(MINUTE, f.SchLocal_OUT, f.ActLocal_OUT) >= 15)
        ) THEN 'CONTROLLABLE'

        WHEN UPPER(COALESCE(dc.DOT_Description, dd.DOT_Description, f.CancelRsn, fd.DelayRsn, '')) LIKE '%WEATHER%' OR
             UPPER(COALESCE(dc.DOT_Description, dd.DOT_Description, f.CancelRsn, fd.DelayRsn, '')) LIKE '%WX%' OR
             UPPER(COALESCE(dc.DOT_Description, dd.DOT_Description, f.CancelRsn, fd.DelayRsn, '')) LIKE '%ATC%' OR
             UPPER(COALESCE(dc.DOT_Description, dd.DOT_Description, f.CancelRsn, fd.DelayRsn, '')) LIKE '%NATIONAL%' OR
             UPPER(COALESCE(dc.DOT_Description, dd.DOT_Description, f.CancelRsn, fd.DelayRsn, '')) LIKE '%SECURITY%' OR
             UPPER(COALESCE(dc.DOT_Description, dd.DOT_Description, f.CancelRsn, fd.DelayRsn, '')) LIKE '%SAFETY%' OR
             UPPER(COALESCE(dc.DOT_Description, dd.DOT_Description, f.CancelRsn, fd.DelayRsn, '')) LIKE '%TSA%'
        THEN 'UNCONTROLLABLE'

        ELSE 'TBD'
    END AS Controllability,

    FORMAT(f.LocalDate, 'yyyyMMdd') + '_' + CAST(f.FlightRecId AS VARCHAR(20)) AS Flight_Key

FROM Reporting.FLIGHT_DATA_MART f
LEFT JOIN Reporting.FlightDelays fd ON f.FlightRecId = fd.FlightRecId
LEFT JOIN Reference.DOT_Cancel_Codes dc ON f.CancelRsn = dc.G4_CXRSN
LEFT JOIN Reference.DOT_Delay_Codes dd ON fd.DelayRsn = dd.IATA_Code
WHERE f.LocalDate >= '2025-06-01' 
  AND f.LocalDate < '2025-07-01'
  AND (
        f.CancelFlag = 1
     OR f.DiversionFlag = 1
     OR DATEDIFF(MINUTE, f.SchLocal_OUT, f.ActLocal_OUT) >= 15
  );

SELECT 
    'IROP SUMMARY' AS Analysis_Type,
    COUNT(*) AS Total_Disruptions,
    COUNT(DISTINCT Flight_ID) AS Unique_Flights,
    SUM(CASE WHEN Controllability = 'CONTROLLABLE' THEN 1 ELSE 0 END) AS Controllable_Disruptions,
    SUM(CASE WHEN Controllability = 'UNCONTROLLABLE' THEN 1 ELSE 0 END) AS Uncontrollable_Disruptions,
    SUM(CASE WHEN Controllability = 'TBD' THEN 1 ELSE 0 END) AS TBD_Disruptions
FROM #RecentIROPEvents;

SELECT 
    Flight_ID,          
    Flight_Key,         
    Flight_Number,
    Flight_Date,
    Origin_Airport,
    Destination_Airport,
    IROP_Type,
    Delay_Bucket,
    Controllability,
    DATEDIFF(MINUTE, Scheduled_Departure, Actual_Departure) AS Delay_Minutes
FROM #RecentIROPEvents
ORDER BY Flight_Date, Flight_Number;

DROP TABLE #RecentIROPEvents;