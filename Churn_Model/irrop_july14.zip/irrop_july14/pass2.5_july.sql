IF OBJECT_ID('tempdb..#HighValueCustomers') IS NOT NULL 
    DROP TABLE #HighValueCustomers;
GO

CREATE TABLE #HighValueCustomers (
    Unique_Customer_Id VARCHAR(40), 
    Revenue_Last_12mo DECIMAL(10,2),
    Total_Bookings INT, 
    Avg_Itinerary_Value DECIMAL(10,2), 
    Last_Booking_Date DATE, 
    HomeAirport VARCHAR(3),
    Bookings_Last_12mo INT,
    Days_Since_Last_Booking INT
); 
GO 

WITH CustomerMetrics AS (
    SELECT  
        c.Unique_Customer_Id, 
        SUM(ISNULL(i.Gross_Revenue, 0)) as Revenue_Last_12mo,
        COUNT(DISTINCT i.Itinerary) as Total_Bookings, 
        AVG(ISNULL(i.Gross_Revenue, 0)) as Avg_Itinerary_Value, 
        MAX(CAST(i.Sys_Start as DATE)) as Last_Booking_Date, 
        c.HomeAirport,
        COUNT(*) as Bookings_Last_12mo,
        DATEDIFF(DAY, MAX(CAST(i.Sys_Start as DATE)), GETDATE()) as Days_Since_Last_Booking,
        AVG(CAST(i.Physical_Pax as FLOAT)) as AveragePassengersPerBooking,
        SUM(i.Physical_Pax) as TotalPassengers,
        CASE 
            WHEN COUNT(DISTINCT i.Itinerary) > 0 
            THEN CAST(SUM(i.Physical_Pax) as FLOAT) / COUNT(DISTINCT i.Itinerary)
            ELSE 0 
        END as PassengerToBookingRatio,
        CASE 
            WHEN CHARINDEX('@', b.EMAIL) > 0 
            THEN LOWER(SUBSTRING(b.EMAIL, CHARINDEX('@', b.EMAIL) + 1, LEN(b.EMAIL)))
            ELSE ''
        END as Domain
    FROM Datamart.Customer_Dim c 
    LEFT JOIN Datamart.Itinerary_Fact i ON c.Unique_Customer_Id = i.Unique_Customer_Id 
    LEFT JOIN Datamart.Booking_Dim b ON i.Itinerary = b.ITINERARY 
    WHERE c.IsActive = 1 
        AND i.Sys_Start >= DATEADD(MONTH, -12, GETDATE())
        AND (b.CANCEL_FLAG IS NULL OR b.CANCEL_FLAG != 'Y') 

        AND c.Email NOT LIKE '%Airline%'
        AND c.Email NOT LIKE '%Travel%'
        AND c.Email NOT LIKE '%TRVL%'
        AND c.Email NOT LIKE '%Allegiant%'
        AND c.Email NOT LIKE '%Destination%'
    GROUP BY c.Unique_Customer_Id, c.HomeAirport, b.EMAIL 
    HAVING COUNT(DISTINCT i.Itinerary) >= 1
)

INSERT INTO #HighValueCustomers
SELECT  
    Unique_Customer_Id, 
    Revenue_Last_12mo,
    Total_Bookings, 
    Avg_Itinerary_Value, 
    Last_Booking_Date, 
    HomeAirport,
    Bookings_Last_12mo,
    Days_Since_Last_Booking
FROM CustomerMetrics
WHERE 
    Total_Bookings < 500
    AND AveragePassengersPerBooking < 6
    AND TotalPassengers < 1000
    AND PassengerToBookingRatio BETWEEN 1.0 AND 4.0
    AND Domain NOT LIKE '%travel%'
    AND Domain NOT LIKE '%agency%'
    AND Domain NOT LIKE '%agent%'
    AND Domain NOT LIKE '%tour%'
    AND Domain NOT LIKE '%trip%'
    AND Domain NOT LIKE '%book%'
    AND Domain NOT LIKE '%group%'
    AND Domain NOT LIKE '%event%'
    AND Domain NOT LIKE '%holiday%'
    AND Domain NOT LIKE '%flightcentre%'
    AND Domain NOT LIKE '%flight%'
    AND Domain NOT LIKE '%voyages%'
    AND Domain NOT LIKE '%trails%'
    AND Domain NOT LIKE '%magnum%'
    AND Domain NOT LIKE '%tpi%'
    AND Domain NOT LIKE '%aaa%'
    AND Domain NOT LIKE '%restel%'
    AND Domain NOT LIKE '%teddy%'
    AND Domain NOT LIKE '%vacation%'
    AND (
        Domain LIKE '%gmail.com%' OR
        Domain LIKE '%yahoo.com%' OR
        Domain LIKE '%hotmail.com%' OR
        Domain LIKE '%outlook.com%' OR
        Domain LIKE '%aol.com%' OR
        Domain LIKE '%icloud.com%'
    );
GO

SELECT  
    hvc.Unique_Customer_Id, 
    i.Itinerary, 
    b.BOOKING_DATETIME, 
    i.TripType, 
    i.Physical_Pax, 
    i.Gross_Revenue, 
    i.Net_Revenue, 
    b.BOOKING_CHANNEL, 
    b.TRAVELPROT as Travel_Protection, 
    i.BundleAncillaryFlag as Bundle_Flag, 
    b.EMAIL as Email_Address, 
    b.GNAME as Guest_Name, 
    hvc.Revenue_Last_12mo,
    hvc.Total_Bookings,
    hvc.Avg_Itinerary_Value,
    hvc.Last_Booking_Date,
    hvc.HomeAirport,
    hvc.Bookings_Last_12mo,
    hvc.Days_Since_Last_Booking,

    CASE 
        WHEN hvc.Revenue_Last_12mo >= 1895 THEN 'HIGH_VALUE'
        WHEN hvc.Revenue_Last_12mo >= 740 THEN 'MEDIUM_VALUE'
        ELSE 'LOW_VALUE'
    END as Customer_Value_Tier,

    CASE 
        WHEN hvc.Days_Since_Last_Booking <= 30 THEN 'Very Recent'
        WHEN hvc.Days_Since_Last_Booking <= 90 THEN 'Recent'
        WHEN hvc.Days_Since_Last_Booking <= 180 THEN 'Moderate'
        ELSE 'Inactive'
    END as Activity_Level,

    CAST(CAST(i.DepartDateKey AS VARCHAR(8)) AS DATE) as Flight_Date,

    i.Flightkey1,
    i.Flightkey2, 
    i.Flightkey3,

    i.FlightKey1Actual,
    i.FlightKey2Actual,
    i.FlightKey3Actual,

    CAST(i.DepartDateKey AS VARCHAR(8)) + '_' + CAST(ISNULL(i.Flightkey1, '') AS VARCHAR(20)) as Flight_Key_1,
    CAST(i.DepartDateKey AS VARCHAR(8)) + '_' + CAST(ISNULL(i.Flightkey2, '') AS VARCHAR(20)) as Flight_Key_2,
    CAST(i.DepartDateKey AS VARCHAR(8)) + '_' + CAST(ISNULL(i.Flightkey3, '') AS VARCHAR(20)) as Flight_Key_3

FROM #HighValueCustomers hvc
INNER JOIN Datamart.Itinerary_Fact i ON hvc.Unique_Customer_Id = i.Unique_Customer_Id 
INNER JOIN Datamart.Booking_Dim b ON i.Itinerary = b.ITINERARY 
WHERE i.Sys_Start >= '2025-06-01' AND i.Sys_Start < '2025-07-01'
    AND i.DepartDateKey BETWEEN 20250601 AND 20250630
    AND (b.CANCEL_FLAG IS NULL OR b.CANCEL_FLAG != 'Y') 
    AND (b.Travel_Agency IS NULL OR b.Travel_Agency = '')
    AND (b.BookedBy IS NULL OR b.BookedBy = b.GNAME)
    AND b.BOOKING_CHANNEL NOT IN ('TA', 'AGENT', 'CORP')
    AND hvc.Revenue_Last_12mo >= 740
    AND (i.Flightkey1 IS NOT NULL OR i.Flightkey2 IS NOT NULL OR i.Flightkey3 IS NOT NULL)

ORDER BY hvc.Revenue_Last_12mo DESC, b.BOOKING_DATETIME DESC;
GO

DROP TABLE #HighValueCustomers;
GO